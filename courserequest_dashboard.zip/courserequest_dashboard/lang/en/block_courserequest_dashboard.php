<?php

$string['pluginname'] = 'Course Requests';
$string['requestcourse'] = 'Request';
$string['requested'] = 'Requested';
$string['approved'] = 'Approved';
$string['rejected'] = 'Rejected';

$string['nocourses'] = 'No new courses available.';

