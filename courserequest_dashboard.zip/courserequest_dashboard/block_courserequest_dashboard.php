<?php
defined('MOODLE_INTERNAL') || die();

class block_courserequest_dashboard extends block_base {

    public function init() {
        $this->title = get_string('pluginname', 'block_courserequest_dashboard');
    }

    public function applicable_formats() {
        return [
            'my' => true // Dashboard only
        ];
    }

    public function get_content() {
        global $CFG, $USER, $DB, $OUTPUT;

        if ($this->content !== null) {
            return $this->content;
        }

        $this->content = new stdClass();
        $this->content->text = '';
        $this->content->footer = '';

        // ===============================
        // Required libs
        // ===============================
        require_once($CFG->dirroot . '/local/iomad/lib/user.php');
        require_once($CFG->dirroot . '/local/iomad/lib/company.php');
        require_once($CFG->dirroot . '/course/classes/list_element.php');

        // ===============================
        // Pagination setup
        // ===============================
        $perpage = 6;
        $page    = optional_param('crpage', 0, PARAM_INT);
        $offset  = $page * $perpage;

        // ===============================
        // Get company
        // ===============================
        $companyid = iomad::get_my_companyid($USER->id);
        if (empty($companyid)) {
            return $this->content;
        }

        // ===============================
        // Ensure Company Manager
        // ===============================
        $company  = new company($companyid);
        $managers = $company->get_company_managers();

        if (!isset($managers[$USER->id])) {
            return $this->content;
        }

        // ===============================
        // Total count (for pagination)
        // ===============================
        $total = $DB->count_records_sql("
            SELECT COUNT(1)
            FROM {course} c
            WHERE c.visible = 1
              AND c.id != 1
        ");

        // ===============================
        // Fetch paginated courses + status
        // ===============================
       $courses = $DB->get_records_sql("
    SELECT 
        c.id,
        c.fullname,

        /* Approved: course assigned to company */
        CASE 
            WHEN cc.id IS NOT NULL THEN 1 
            ELSE 0 
        END AS isapproved,

        /* Requested but still pending */
        CASE 
            WHEN r.id IS NOT NULL AND r.status = 'pending' THEN 1 
            ELSE 0 
        END AS isrequested,

        /* Rejected request */
        CASE 
            WHEN r.id IS NOT NULL AND r.status = 'rejected' THEN 1 
            ELSE 0 
        END AS isrejected

    FROM {course} c

    LEFT JOIN {company_course} cc
           ON cc.courseid = c.id
          AND cc.companyid = ?

    LEFT JOIN {local_courserequest} r
           ON r.courseid = c.id
          AND r.companyid = ?

    WHERE c.visible = 1
      AND c.id != 1

    ORDER BY c.timecreated DESC
    LIMIT {$perpage} OFFSET {$offset}
", [$companyid, $companyid]);


        if (empty($courses)) {
            $this->content->text = html_writer::div(
                get_string('nocourses', 'block_courserequest_dashboard'),
                'alert alert-info'
            );
            return $this->content;
        }

        // ===============================
        // Render Academi-style grid
        // ===============================
        $html = html_writer::start_div('row');

        foreach ($courses as $course) {

            $html .= html_writer::start_div('col-xl-4 col-lg-4 col-md-6 col-sm-12 mb-3');
            $html .= html_writer::start_div('card h-100');

            // ---- Course image (Academi way) ----
            $courseelement = new core_course_list_element($course);
            $overviewfiles = $courseelement->get_course_overviewfiles();

            if (!empty($overviewfiles)) {
                $file = reset($overviewfiles);

                $imgurl = moodle_url::make_pluginfile_url(
                    $file->get_contextid(),
                    $file->get_component(),
                    $file->get_filearea(),
                    null,
                    $file->get_filepath(),
                    $file->get_filename()
                );

                $html .= html_writer::empty_tag('img', [
                    'src'   => $imgurl,
                    'class' => 'card-img-top',
                    'alt'   => format_string($course->fullname)
                ]);
            }

            $html .= html_writer::start_div('card-body d-flex flex-column');

            // ---- Course title ----
            $html .= html_writer::tag(
                'h6',
                format_string($course->fullname),
                ['class' => 'card-title mb-3']
            );

            // ---- Button area ----
            $html .= html_writer::start_div('mt-auto text-end');

            if ($course->isapproved) {

                $html .= html_writer::tag(
                    'button',
                    get_string('approved', 'block_courserequest_dashboard'),
                    [
                        'class' => 'btn btn-sm btn-success',
                        'disabled' => 'disabled'
                    ]
                );

            } elseif ($course->isrequested) {

                $html .= html_writer::tag(
                    'button',
                    get_string('requested', 'block_courserequest_dashboard'),
                    [
                        'class' => 'btn btn-sm btn-secondary',
                        'disabled' => 'disabled'
                    ]
                );

            }elseif($course->isrejected){
                  $html .= html_writer::tag(
                    'button',
                    get_string('rejected', 'block_courserequest_dashboard'),
                    [
                        'class' => 'btn btn-sm btn-secondary',
                        'disabled' => 'disabled'
                    ]
                );

            } else {

                $url = new moodle_url(
                    '/local/courserequest/request.php',
                    [
                        'courseid' => $course->id,
                        'sesskey'  => sesskey()
                    ]
                );

                $html .= html_writer::link(
                    $url,
                    get_string('requestcourse', 'block_courserequest_dashboard'),
                    ['class' => 'btn btn-sm btn-primary']
                );
            }

            $html .= html_writer::end_div(); // action
            $html .= html_writer::end_div(); // card-body
            $html .= html_writer::end_div(); // card
            $html .= html_writer::end_div(); // col
        }

        $html .= html_writer::end_div(); // row

        $this->content->text = $html;

        // ===============================
        // Pagination bar
        // ===============================
        $baseurl = new moodle_url('/my/index.php');
        $pagingbar = new paging_bar($total, $page, $perpage, $baseurl, 'crpage');

        $this->content->footer = $OUTPUT->render($pagingbar);

        return $this->content;
    }
}
