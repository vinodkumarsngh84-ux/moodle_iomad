<?php
defined('MOODLE_INTERNAL') || die();

class block_courserequest_admin extends block_base {

    public function init() {
        $this->title = get_string('pluginname', 'block_courserequest_admin');
    }

    public function applicable_formats() {
        return [
            'my' => true // Admin dashboard only
        ];
    }

    public function instance_allow_multiple() {
        return false;
    }

    public function get_content() {
        global $CFG, $DB;

        if ($this->content !== null) {
            return $this->content;
        }

        $this->content = new stdClass();
        $this->content->text = '';

        // 🔐 Admin only
        if (!has_capability('moodle/site:config', context_system::instance())) {
            return $this->content;
        }

        require_once($CFG->dirroot . '/local/iomad/lib/company.php');

        // Fetch pending requests
        $requests = $DB->get_records_sql("
            SELECT r.*, 
                   c.fullname AS coursename,
                   u.firstname,
                   u.lastname
            FROM {local_courserequest} r
            JOIN {course} c ON c.id = r.courseid
            JOIN {user} u   ON u.id = r.managerid
            WHERE r.status = 'pending'
            ORDER BY r.timecreated DESC
            LIMIT 5
        ");

        if (empty($requests)) {
            $this->content->text = html_writer::div(
                get_string('norequests', 'block_courserequest_admin'),
                'alert alert-info'
            );
            return $this->content;
        }

        $list = html_writer::start_tag('ul', ['class' => 'list-group']);

        foreach ($requests as $r) {

            $company = new company($r->companyid);

            $approveurl = new moodle_url(
                '/local/courserequest/approve.php',
                [
                    'id' => $r->id,
                    'sesskey' => sesskey()
                ]
            );

            $approvebtn = html_writer::link(
                $approveurl,
                get_string('approve', 'block_courserequest_admin'),
                ['class' => 'btn btn-sm btn-success mt-2']
            );

            $item = html_writer::div(
                '<strong>' . format_string($r->coursename) . '</strong><br>' .
                format_string($company->get_name()) . '<br>' .
                'Requested by: ' . fullname($r) . '<br>' .
                'Seats: ' . $r->seats . '<br>' .
                'Start: ' . userdate($r->startdate) . '<br>' .
                'End: ' . userdate($r->enddate) . '<br>' .
                $approvebtn
            );

            $list .= html_writer::tag(
                'li',
                $item,
                ['class' => 'list-group-item']
            );
        }

        $list .= html_writer::end_tag('ul');

        $this->content->text = $list;
        return $this->content;
    }
}
