<?php
defined('MOODLE_INTERNAL') || die();

$capabilities = [

    'block/courserequest_admin:addinstance' => [
        'captype' => 'write',
        'contextlevel' => CONTEXT_SYSTEM,
        'archetypes' => [
            'manager' => CAP_PROHIBIT,
            'editingteacher' => CAP_PROHIBIT,
            'teacher' => CAP_PROHIBIT,
            'student' => CAP_PROHIBIT,
            'admin' => CAP_ALLOW,
        ],
    ],

];
