<?php
defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Pending Course Requests';
$string['approve'] = 'Approve';
$string['norequests'] = 'No pending course requests.';
