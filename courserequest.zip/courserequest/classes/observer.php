<?php
namespace local_courserequest;

defined('MOODLE_INTERNAL') || die();

class observer {

    public static function course_created(\core\event\course_created $event) {
        global $DB, $CFG;

        require_once($CFG->dirroot . '/local/iomad/lib/company.php');

        $courseid = $event->objectid;
        $course   = $DB->get_record('course', ['id' => $courseid], '*', MUST_EXIST);

        $companies = $DB->get_records('company');

        foreach ($companies as $company) {

            $companyobj = new \company($company->id);
            $managers = $companyobj->get_company_managers();

            foreach ($managers as $manager) {

                // 🔥 FIX: load real user
                $user = $DB->get_record(
                    'user',
                    ['id' => $manager->userid, 'deleted' => 0, 'suspended' => 0]
                );

                if (!$user || empty($user->email)) {
                    continue;
                }

                email_to_user(
                    $user,
                    \core_user::get_noreply_user(),
                    get_string('email:newcourse:subject', 'local_courserequest'),
                    get_string(
                        'email:newcourse:body',
                        'local_courserequest',
                        (object)['coursename' => $course->fullname]
                    )
                );
            }
        }
    }
}
