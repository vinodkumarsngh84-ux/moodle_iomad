<?php
namespace local_courserequest;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/blocks/iomad_company_admin/lib.php');

class iomad_helper {

    /**
     * Get current user's company id
     */
    public static function get_user_companyid($userid = null) {
        global $USER;

        if (!$userid) {
            $userid = $USER->id;
        }

        return \iomad::get_my_companyid($userid);
    }

    /**
     * Get company managers
     */
    public static function get_company_managers($companyid) {
       $company = new \company($companyid);
	   return $company->get_company_managers();

	   
    }

    /**
     * Assign course to company (official IOMAD way)
     */
    public static function assign_course($companyid, $courseid) {
        \company::assign_course_to_company($companyid, $courseid);
    }
}
