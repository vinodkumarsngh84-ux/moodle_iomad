<?php
namespace local_courserequest;

defined('MOODLE_INTERNAL') || die();

class manager_courses {

    public static function get_available_courses($companyid) {
    global $DB;

    return $DB->get_records_sql("
        SELECT c.*
        FROM {course} c
        WHERE c.visible = 1
          AND c.id != 1
          AND NOT EXISTS (
              SELECT 1
              FROM {company_course} cc
              WHERE cc.courseid = c.id
                AND cc.companyid = ?
          )
    ", [$companyid]);
}

}


