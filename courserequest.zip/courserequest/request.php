<?php
require_once('../../config.php');
require_login();
require_sesskey();

require_once($CFG->dirroot . '/local/iomad/lib/user.php');
require_once($CFG->dirroot . '/local/iomad/lib/company.php');
require_once($CFG->dirroot . '/local/courserequest/forms/request_form.php');

$courseid = required_param('courseid', PARAM_INT);

$course = $DB->get_record('course', ['id' => $courseid], '*', MUST_EXIST);

// Company check
$companyid = iomad::get_my_companyid($USER->id);
if (!$companyid) {
    throw new moodle_exception('error:nocompany', 'local_courserequest');
}

// Company manager check
$company = new company($companyid);
$managers = $company->get_company_managers();
if (!isset($managers[$USER->id])) {
    throw new moodle_exception('error:permissiondenied', 'local_courserequest');
}

// Prevent duplicate request
if ($DB->record_exists('local_courserequest', [
    'companyid' => $companyid,
    'courseid'  => $courseid
])) {
    redirect(
        new moodle_url('/my/index.php'),
        get_string('alreadyrequested', 'local_courserequest'),
        null,
        \core\output\notification::NOTIFY_WARNING
    );
}

// Setup page
$PAGE->set_url('/local/courserequest/request.php', ['courseid' => $courseid]);
$PAGE->set_title(get_string('requestcourse', 'local_courserequest'));
$PAGE->set_heading(get_string('requestcourse', 'local_courserequest'));

$form = new local_courserequest_request_form(
    null,
    ['course' => $course]
);

if ($form->is_cancelled()) {
    redirect(new moodle_url('/my/index.php'));
}

if ($data = $form->get_data()) {

    $record = new stdClass();
    $record->companyid  = $companyid;
    $record->courseid   = $data->courseid;
    $record->seats      = $data->seats;
    $record->startdate  = $data->startdate;
    $record->enddate    = $data->enddate;
    $record->managerid  = $USER->id;
    $record->status     = 'pending';
    $record->timecreated = time();

    $DB->insert_record('local_courserequest', $record);


    require_once($CFG->libdir . '/moodlelib.php');
    $admins = get_admins();
    $company = new company($companyid);
    $manager = $DB->get_record('user', ['id' => $USER->id], '*', MUST_EXIST);
    $subject = get_string('adminemailsubject', 'local_courserequest');
    $a = new stdClass();
    $a->coursename   = $course->fullname;
    $a->companyname  = $company->get_name();
    $a->managername  = fullname($manager);
    $a->manageremail = $manager->email;
    $a->seats        = $record->seats;
    $a->startdate    = userdate($record->startdate);
    $a->enddate      = userdate($record->enddate);
    $body = get_string('adminemailbody', 'local_courserequest', $a);
    foreach ($admins as $admin) {
     if (empty($admin->email) || $admin->suspended || $admin->deleted) {
            continue;
        }

        email_to_user(
            $admin,
            core_user::get_noreply_user(),
            $subject,
            $body
        );
    }
redirect(
        new moodle_url('/my/index.php'),
        get_string('requestsubmitted', 'local_courserequest'),
        null,
        \core\output\notification::NOTIFY_SUCCESS
    );
}

// Render form
echo $OUTPUT->header();
$form->display();
echo $OUTPUT->footer();

