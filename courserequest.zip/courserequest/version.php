<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_courserequest';
$plugin->version   = 2026012601;   
$plugin->requires  = 2024042200;
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '1.5';
