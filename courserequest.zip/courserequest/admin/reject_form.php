<?php
require_once($CFG->libdir . '/formslib.php');

class local_courserequest_reject_form extends moodleform {

    public function definition() {
        $mform = $this->_form;

        // 🔹 Request ID (IMPORTANT)
        $mform->addElement('hidden', 'id');
        $mform->setType('id', PARAM_INT);

        // 🔹 Rejection reason
        $mform->addElement(
            'textarea',
            'reason',
            get_string('rejectreason', 'local_courserequest'),
            ['rows' => 5]
        );
        $mform->setType('reason', PARAM_TEXT);
        $mform->addRule('reason', null, 'required', null, 'client');

        $this->add_action_buttons(true, get_string('reject', 'local_courserequest'));
    }
}
