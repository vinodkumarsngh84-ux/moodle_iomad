<?php
require_once('../../../config.php');
require_login();

require_capability('moodle/site:config', context_system::instance());
require_once($CFG->dirroot . '/local/iomad/lib/company.php');

$page     = optional_param('page', 0, PARAM_INT);
$perpage  = 10;
$offset   = $page * $perpage;

$PAGE->set_url('/local/courserequest/admin/approvals.php', ['page' => $page]);
$PAGE->set_title(get_string('pendingrequests', 'local_courserequest'));
$PAGE->set_heading(get_string('pendingrequests', 'local_courserequest'));

echo $OUTPUT->header();

/* ---- total count ---- */
$total = $DB->count_records('local_courserequest', ['status' => 'pending']);

/* ---- fetch requests ---- */
$requests = $DB->get_records_sql("
    SELECT r.*, c.fullname AS coursename,
           u.firstname, u.lastname, u.email
      FROM {local_courserequest} r
      JOIN {course} c ON c.id = r.courseid
      JOIN {user} u   ON u.id = r.managerid
     WHERE r.status = 'pending'
     ORDER BY r.timecreated DESC
     LIMIT {$perpage} OFFSET {$offset}
");

if (!$requests) {
    echo $OUTPUT->notification(
        get_string('norequests', 'local_courserequest'),
        \core\output\notification::NOTIFY_INFO
    );
    echo $OUTPUT->footer();
    exit;
}

/* ---- table ---- */
$table = new html_table();
$table->attributes['class'] = 'generaltable table-striped';

$table->head = [
    get_string('course'),
    get_string('company', 'local_courserequest'),
    get_string('requestedby', 'local_courserequest'),
    get_string('seats', 'local_courserequest'),
    get_string('startdate', 'local_courserequest'),
    get_string('enddate', 'local_courserequest'),
    get_string('action')
];

foreach ($requests as $r) {

    $company = new company($r->companyid);

    $approveurl = new moodle_url(
        '/local/courserequest/approve.php',
        ['id' => $r->id, 'sesskey' => sesskey()]
    );

    $rejecturl = new moodle_url(
        '/local/courserequest/admin/reject.php',
        ['id' => $r->id]
    );

    $actions =
        html_writer::link($approveurl, get_string('approve', 'local_courserequest'),
            ['class' => 'btn btn-sm btn-success mr-2']) .
        html_writer::link($rejecturl, get_string('reject', 'local_courserequest'),
            ['class' => 'btn btn-sm btn-danger']);

    $table->data[] = [
        format_string($r->coursename),
        format_string($company->get_name()),
        fullname($r) . '<br>' . s($r->email),
        (int)$r->seats,
        userdate($r->startdate),
        userdate($r->enddate),
        $actions
    ];
}

echo html_writer::table($table);

/* ---- pagination ---- */
$baseurl = new moodle_url('/local/courserequest/admin/approvals.php');
echo $OUTPUT->render(new paging_bar($total, $page, $perpage, $baseurl));

echo $OUTPUT->footer();
