<?php
require_once('../../../config.php');
require_login();

// Admin only
require_capability('moodle/site:config', context_system::instance());

// Get request id from URL (GET)
$id = required_param('id', PARAM_INT);

require_once($CFG->dirroot . '/local/courserequest/admin/reject_form.php');

$PAGE->set_url('/local/courserequest/admin/reject.php', ['id' => $id]);
$PAGE->set_title(get_string('reject', 'local_courserequest'));
$PAGE->set_heading(get_string('reject', 'local_courserequest'));

// Create form
$form = new local_courserequest_reject_form();

// ✅ IMPORTANT: populate hidden field
$form->set_data([
    'id' => $id
]);

// Cancel
if ($form->is_cancelled()) {
    redirect(new moodle_url('/local/courserequest/admin/approvals.php'));
}

// Form submitted
if ($data = $form->get_data()) {

    require_sesskey();

    // Load request using submitted ID
    $request = $DB->get_record(
        'local_courserequest',
        ['id' => $data->id],
        '*',
        MUST_EXIST
    );

    // Update request
    $request->status = 'rejected';
    $request->rejectreason = $data->reason;
    $request->timemodified = time();

    $DB->update_record('local_courserequest', $request);

    redirect(
        new moodle_url('/local/courserequest/admin/approvals.php'),
        get_string('requestrejected', 'local_courserequest'),
        null,
        \core\output\notification::NOTIFY_SUCCESS
    );
}

// Display form
echo $OUTPUT->header();
$form->display();
echo $OUTPUT->footer();
