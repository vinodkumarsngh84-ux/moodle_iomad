<?php

require_once('../../config.php');
require_login();

require_capability('moodle/site:config', context_system::instance());

require_once($CFG->dirroot . '/local/iomad/lib/user.php');
require_once($CFG->dirroot . '/local/iomad/lib/company.php');

$id = required_param('id', PARAM_INT);

$request = $DB->get_record(
    'local_courserequest',
    ['id' => $id],
    '*',
    MUST_EXIST
);


$course = $DB->get_record('course', ['id' => $request->courseid], '*', MUST_EXIST);
$company  = new company($request->companyid);

//$departmentid = $request->companyid;

// Get company root department (IOMAD-safe)
$departmentid = $DB->get_field(
    'department',
    'id',
    [
        'company' => $request->companyid,
        'parent'    => 0
    ],
    MUST_EXIST
);




$exists = $DB->record_exists('company_course', [
    'companyid' => $request->companyid,
    'courseid'  => $request->courseid
]);

if (!$exists) {
    $cc = new stdClass();
    $cc->companyid   = $request->companyid;
    $cc->courseid    = $request->courseid;
	$cc->departmentid = $departmentid;
	$cc->timecreated = time();
    $DB->insert_record('company_course', $cc);
}


$request->status = 'approved';
$DB->update_record('local_courserequest', $request);

$company  = new company($request->companyid);
$managers = $company->get_company_managers();


foreach ($managers as $manager) {
 
    $user = $DB->get_record('user', ['id' => $manager->userid], '*', IGNORE_MISSING);


    if (!$user) {
        error_log('EMAIL SKIPPED: Invalid user id ' . $manager->userid);
        continue;
    }

    if ($user->deleted || $user->suspended || empty($user->email)) {
        error_log('EMAIL SKIPPED: User not emailable ' . $user->id);
        continue;
    }

    $subject = get_string('email:approval:subject', 'local_courserequest');

    $data = (object)[
        'managername' => fullname($user),
        'coursename'  => $course->fullname
    ];

    $body = get_string('email:approval:body', 'local_courserequest', $data);

    $result = email_to_user(
        $user,
        core_user::get_noreply_user(),
        $subject,
        $body
    );

    error_log('EMAIL RESULT for user '.$user->id.' : ' . ($result ? 'SUCCESS' : 'FAILED'));
}




// 4️⃣ Redirect back to approvals
redirect(
    new moodle_url('/local/courserequest/admin/approvals.php'),
    get_string('requestapproved', 'local_courserequest')
);
