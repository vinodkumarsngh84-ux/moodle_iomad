<?php
// This file is part of Moodle - http://moodle.org/
//
// Local Course Request language strings
//
// @package    local_courserequest
// @copyright  2026
// @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later

defined('MOODLE_INTERNAL') || die();

/* Plugin name */
$string['pluginname'] = 'Course Request Management';

/* Navigation / Menu */
$string['availablecourses'] = 'Available Courses';
$string['requestcourse'] = 'Request Course';

/* Page titles */
$string['availablecoursestitle'] = 'Available Courses for Request';
$string['courserequestdashboard'] = 'Course Request Dashboard';

/* Actions & messages */
$string['requestsubmitted'] = 'Course request submitted successfully.';
$string['requestalreadyexists'] = 'You have already requested this course.';
$string['requestapproved'] = 'Course request approved successfully.';
$string['requestrejected'] = 'Course request rejected.';

/* Email notifications */
$string['email:newcourse:subject'] = 'New Course Available';
$string['email:newcourse:body'] =
'A new course "{$a->coursename}" has been created in the system.

Please login to your dashboard to request this course for your center.';

$string['email:requestapproved:subject'] = 'Course Request Approved';
$string['email:requestapproved:body'] =
'Your requested course "{$a->coursename}" has been approved and assigned to your center.';

/* Capabilities */
$string['courserequest:request'] = 'Request courses for center';

/* Admin */
$string['pendingrequests'] = 'Pending Course Requests';
$string['approve'] = 'Approve';
$string['reject'] = 'Reject';

/* Errors */
$string['error:nocompany'] = 'No center associated with this user.';
$string['error:invalidcourse'] = 'Invalid course selected.';
$string['error:permissiondenied'] = 'You do not have permission to perform this action.';
$string['email:approval:subject'] = 'Course Assigned Successfully';
$string['email:approval:body'] =
'Dear {$a->managername},

The course "{$a->coursename}" has been approved and assigned to your center.

You can now manage enrolments for this course from your dashboard.

Regards,
LMS Administration Team';


$string['requestcourse'] = 'Request Course';
$string['seats'] = 'Number of seats';
$string['startdate'] = 'Start date';
$string['enddate'] = 'End date';
$string['submitrequest'] = 'Submit request';

$string['invalidseats'] = 'Number of seats must be greater than zero.';
$string['invaliddate'] = 'End date must be after start date.';
$string['alreadyrequested'] = 'You have already requested this course.';
$string['requestsubmitted'] = 'Course request submitted successfully.';

$string['adminemailsubject'] = 'New course request submitted';

$string['adminemailbody'] =
'Dear Admin,

A new course request has been submitted.

Course: {$a->coursename}
Company: {$a->companyname}

Requested by:
Name: {$a->managername}
Email: {$a->manageremail}

Requested details:
Number of seats: {$a->seats}
Start date: {$a->startdate}
End date: {$a->enddate}

Please log in to the admin dashboard to review and approve this request.

Regards,
LMS System';


$string['norequests'] = 'No pending course requests found.';
$string['requestedby'] = 'Requested by';
$string['company'] = 'Center';

$string['reject'] = 'Reject';
$string['rejectreason'] = 'Rejection reason';
$string['requestrejected'] = 'Course request rejected.';
$string['requestedby'] = 'Requested by';
$string['company'] = 'Company';
