<?php
$capabilities = [
    'local/courserequest:request' => [
        'captype' => 'write',
        'contextlevel' => CONTEXT_SYSTEM,
        'archetypes' => [
            'companymanager' => CAP_ALLOW
        ]
    ]
];
