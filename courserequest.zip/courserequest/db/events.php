<?php
$observers = [
    [
        'eventname' => '\core\event\course_created',
        'callback'  => '\local_courserequest\observer::course_created',
    ],
];
