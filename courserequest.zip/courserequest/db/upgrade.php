<?php
defined('MOODLE_INTERNAL') || die();

/**
 * Upgrade script for local_courserequest
 *
 * @param int $oldversion
 * @return bool
 */
function xmldb_local_courserequest_upgrade($oldversion) {
    global $DB;

    $dbman = $DB->get_manager();

    /*
     * Upgrade step: Add seats, startdate, enddate
     * Version: 2026012201
     */
    if ($oldversion < 2026012201) {

        $table = new xmldb_table('local_courserequest');

        // ---------- seats ----------
        $field = new xmldb_field(
            'seats',
            XMLDB_TYPE_INTEGER,
            '10',
            null,
            XMLDB_NOTNULL,
            null,
            0,
            'courseid'
        );

        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // ---------- startdate ----------
        $field = new xmldb_field(
            'startdate',
            XMLDB_TYPE_INTEGER,
            '10',
            null,
            XMLDB_NOTNULL,
            null,
            0,
            'seats'
        );

        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // ---------- enddate ----------
        $field = new xmldb_field(
            'enddate',
            XMLDB_TYPE_INTEGER,
            '10',
            null,
            XMLDB_NOTNULL,
            null,
            0,
            'startdate'
        );

        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Savepoint
        upgrade_plugin_savepoint(true, 2026012201, 'local', 'courserequest');
    }

    /*
     * Upgrade step: Add rejectreason
     * Version: 2026012501
     */
   if ($oldversion < 2026012501) {

        $table = new xmldb_table('local_courserequest');

        $field = new xmldb_field(
            'rejectreason',
            XMLDB_TYPE_TEXT,
            null,
            null,
            null,
            null,
            null,
            'status'
        );

        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Savepoint
        upgrade_plugin_savepoint(true, 2026012501, 'local', 'courserequest');
    } 

    return true;
}
