<?php
defined('MOODLE_INTERNAL') || die();

/**
 * Add link to Company Manager dashboard / navigation
 */
function local_courserequest_extend_navigation_user_settings($navigation) {
    global $USER;

    if (has_capability('local/courserequest:request', context_system::instance())) {
        $url = new moodle_url('/local/courserequest/index.php');
        $navigation->add(
            get_string('availablecourses', 'local_courserequest'),
            $url
        );
    }
}
