<?php
require_once($CFG->libdir . '/formslib.php');

class local_courserequest_request_form extends moodleform {

    public function definition() {
        $mform = $this->_form;

        $course = $this->_customdata['course'];

        /* ===============================
         * Course (read-only)
         * =============================== */
        $mform->addElement(
            'static',
            'coursename',
            get_string('course'),
            format_string($course->fullname)
        );

        $mform->addElement('hidden', 'courseid', $course->id);
        $mform->setType('courseid', PARAM_INT);

        /* ===============================
         * Number of seats
         * =============================== */
        $mform->addElement('text', 'seats', get_string('seats', 'local_courserequest'));
        $mform->setType('seats', PARAM_INT);
        $mform->addRule('seats', null, 'required', null, 'client');

        /* ===============================
         * Start date
         * =============================== */
        $mform->addElement('date_selector', 'startdate', get_string('startdate', 'local_courserequest'));
        $mform->addRule('startdate', null, 'required', null, 'client');

        /* ===============================
         * End date
         * =============================== */
        $mform->addElement('date_selector', 'enddate', get_string('enddate', 'local_courserequest'));
        $mform->addRule('enddate', null, 'required', null, 'client');

        /* ===============================
         * Buttons
         * =============================== */
        $this->add_action_buttons(true, get_string('submitrequest', 'local_courserequest'));
    }

    /**
     * Server-side validation (SAFE)
     */
    public function validation($data, $files) {
        $errors = [];

        if (empty($data['seats']) || $data['seats'] <= 0) {
            $errors['seats'] = get_string('invalidseats', 'local_courserequest');
        }

        if ($data['enddate'] <= $data['startdate']) {
            $errors['enddate'] = get_string('invaliddate', 'local_courserequest');
        }

        return $errors;
    }
}
