<?php
require_once('../../config.php');
require_login();

require_once($CFG->dirroot . '/local/iomad/lib/user.php');
require_once($CFG->dirroot . '/local/iomad/lib/company.php');

$PAGE->set_url('/local/courserequest/index.php');
$PAGE->set_context(context_system::instance());
$PAGE->set_title(get_string('availablecourses', 'local_courserequest'));
$PAGE->set_heading(get_string('availablecourses', 'local_courserequest'));

$companyid = iomad::get_my_companyid($USER->id);

if (empty($companyid)) {
    throw new moodle_exception('error:nocompany', 'local_courserequest');
}

$company = new company($companyid);
$managers = $company->get_company_managers();

$managerids = array_keys($managers);

if (!in_array($USER->id, $managerids)) {
    throw new moodle_exception('error:permissiondenied', 'local_courserequest');
}


echo $OUTPUT->header();

$courses = \local_courserequest\manager_courses::get_available_courses($companyid);

foreach ($courses as $course) {
    echo html_writer::div(
        format_string($course->fullname) .
        ' <a href="request.php?courseid=' . $course->id . '">' .
        get_string('requestcourse', 'local_courserequest') .
        '</a>'
    );
}

echo $OUTPUT->footer();
